# tcp_client.py
# code to support tcp connection to networked socket servers

import time
import sys
import socket
import threading
import collections
from Queue import Queue
import traceback

import logging
log = logging.getLogger(__name__)

class SockClient():
    def __init__(self, ip_addr, port):
        self.eventQ = Queue()  # for incoming client messages
        self.ip_addr = ip_addr
        self.port = port
        self.thr = None
        self.status = collections.namedtuple('State','connected thr_running')
        self.status.connected = False
        self.status.thr_running = False
        self.is_connected = False
        log.info('TCP client ready to connect to %s:%d', self.ip_addr, self.port)

    def connect(self):
        log.info('Attempting to connect to %s:%d', self.ip_addr, self.port)
        # Create a TCP/IP socket to service remote clients
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except Exception, e:
            log.error("error creating client socket %s", e)
            raise
        try:
            self.sock.connect((self.ip_addr, self.port))
            self.status.connected = True
            self.thr = threading.Thread(target=self.listener_thread, args= (self.sock, self.eventQ,self.status,))
            self.thr.daemon = True
            self.thr.start()
            self.status.running = True
            log.info('Connected to %s:%d', self.ip_addr, self.port)
        except socket.error, e: 
            self.status.connected = False
            log.debug("client socket error %s", e)
            self.sock.close()
        except Exception, e:
            log.error("Error connecting to client %s", e)
            self.status.connected = False
            raise

    def disconnect(self):
        self.status.connected = False
        while self.status.running:
            time.sleep(.1)
            print '.'
        print "no longer running"
        if self.thr:
            self.thr.join()
        self.sock.close()
        log.debug("client socket closed")

    def send_cmd(self, cmd):
        if self.status.connected:
            try: 
               self.sock.sendall(cmd)
            except socket.error as error:
                if error.errno == socket.errno.WSAECONNRESET:
                    log.error("got disconnect error on connection to %s", self.ip_addr)
                    self.disconnect() # kill thread
                elif error.errno == 10057:
                    log.warning("socket not connected, is target running")
                    self.disconnect() # kill thread
                else:
                   self.status.connected = False
                   log.error("error in client socket send");
                   self.disconnect() # kill thread

    def receive(self):
        if self.eventQ.empty():
            return None
        else:   
            return self.eventQ.get()

    def service(self):
        pass # 
 
    def listener_thread(self, sock, inQ, flags):
        # This method receives client events 
        msg = ""
        while flags.connected:
            try:
                msg += sock.recv(512)
                while True:
                    end = msg.find('\n')
                    if end > 0:
                       inQ.put(msg[:end])
                       # log.debug("in client thread, msg=%s", msg[:end])
                       msg = msg[end+1:]
                    else:
                        break
            except socket.error, e: 
               log.error("socket error in thread %s", e)
               flags.connected = False
               break
            except Exception:
                log.error("unhandled listener thread err %s", e)
        log.debug("terminating tcp client thread")
        flags.running = False


import logging.handlers
import logging as log

def start_logging(level):
    log_format = log.Formatter('%(asctime)s,%(levelname)s,%(message)s')
    logger = log.getLogger()
    logger.setLevel(level)

    file_handler = logging.handlers.RotatingFileHandler("local_client.log", maxBytes=(10240 * 5), backupCount=2)
    file_handler.setFormatter(log_format)
    logger.addHandler(file_handler)

    console_handler = log.StreamHandler(sys.stdout)
    console_handler.setFormatter(log_format)
    logger.addHandler(console_handler)   
    
if __name__ == "__main__":
    import msvcrt # for kbhit
    
    start_logging(logging.DEBUG)
    client = SockClient('127.0.0.1', 10015)
    while True:
        try:
            if not client.status.connected:
                client.connect()
            else: 
                msg = "telemetry"
                print "sending msg:",  msg
                client.send_cmd(msg)
                client.service()
        except Exception, e:
            print( "err", str(e))
        if msvcrt.kbhit(): 
            key = msvcrt.getch()
            if ord(key) == 27: # esc
                break
            elif client.status.connected:
                if key == 'd': cmd = 'dispatch'
                elif key == 'p': cmd = 'pause'
                elif cmd == 'r': cmd = 'reset'
                else: cmd == str(key)
                client.send_cmd(cmd)
        time.sleep(.5)
        while True:
            event = client.receive()
            if event:
                print "got:", event
            else:
                break
                
    client.disconnect()
